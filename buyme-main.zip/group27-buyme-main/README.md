# group 27 buyme
- Sean Kim (skk135)
- Sumedh Sinha (ss4219)
- Maxwell Chuo (mhc88)
- Dylan Legg (dl1073)